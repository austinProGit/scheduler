import sqlite3 
from course import Course

#below creates the connection between the pyfile and the db file
#using :memory: in place of a file name will create the db file in ram 
#this allows for easier testing/debudding as you dont have to comment out insert statements 
#removes error 'table already created'
#recommended file name 'courses.db'
conn = sqlite3.connect(':memory:')
#conn = sqlite3.connect('courses.db')

#creates cursor to execute commands 
c = conn.cursor()

#create course table
c.execute("""CREATE TABLE courses (
             CourseID text,
             Schedule text,
             PrereqId text,
             Instructor text,
             CreditHours integer,
             isElective text,
             Weight integer
            )""")

def insert_course(course):
    #'with' removes the need for committing and will rollback if error (INSERT statements need commit)
    with conn:
        c.execute("INSERT INTO courses VALUES (:CourseID, :Schedule, :PrereqID, :Instructor, :CreditHours, :isElective, :Weight)", 
        {'CourseID': course.CourseId, 'Schedule': course.Schedule, 'PrereqID': course.PrereqId, 'Instructor': course.Instructor, 
        'CreditHours': course.CreditHours, 'isElective': course.isElective, 'Weight': course.Weight})

def get_all_courses():
    #SELECT statements do not need commit - so they dont need with condition
    c.execute("SELECT * FROM courses")
    return c.fetchall()

def get_courses_by_id(CourseID):
    c.execute("SELECT * FROM courses WHERE CourseID=:CourseID", {'CourseID': CourseID})
    return c.fetchall()

def get_courses_by_schedule(Schedule):
    c.execute("SELECT * FROM courses WHERE Schedule=:Schedule", {'Schedule': Schedule})
    return c.fetchall()

def get_courses_by_prereqId(PrereqId):
    c.execute("SELECT * FROM courses WHERE PrereqId=:PrereqId", {'PrereqId': PrereqId})
    return c.fetchall()

def get_courses_by_instructor(Instructor):
    c.execute("SELECT * FROM courses WHERE Instructor=:Instructor", {'Instructor': Instructor})
    return c.fetchall()

def get_courses_by_credit_hours(CreditHours):
    c.execute("SELECT * FROM courses WHERE CreditHours=:CreditHours", {'CreditHours': CreditHours})
    return c.fetchall()

def get_courses_by_isElective(isElective):
    c.execute("SELECT * FROM courses WHERE isElective=:isElective", {'isElective': isElective})
    return c.fetchall()

def get_courses_by_weight(Weight):
    c.execute("SELECT * FROM courses WHERE Weight>=:Weight", {'Weight': Weight})
    return c.fetchall()

#functions below had to be changed from 'Course.ID': course.CourseID to course.get_courseID as course is private

def update_course_id(course, newCourseID):
    with conn:
            c.execute("""UPDATE courses SET CourseID = :newCourseID
                        WHERE CourseID = :CourseID""",
                        {'CourseID': course.get_courseID(), 'newCourseID': newCourseID})
            course.set_courseID(newCourseID)

def update_schedule(course, Schedule):
    with conn:
        c.execute("""UPDATE courses SET Schedule = :Schedule
                    WHERE CourseID = :CourseID""",
                    {'CourseID': course.get_courseID(), 'Schedule': Schedule})
        course.set_schedule(Schedule)


def update_prereqId(course, PrereqId):
    with conn:
        c.execute("""UPDATE courses SET PrereqId = :PrereqId
                    WHERE CourseID = :CourseID""",
                    {'CourseID': course.get_courseID(), 'PrereqId': PrereqId})
        course.set_prereqId(PrereqId)
        
def update_instructor(course, Instructor):
    with conn:
        c.execute("""UPDATE courses SET Instructor = :Instructor
                    WHERE CourseID = :CourseID""",
                    {'CourseID': course.get_courseID(), 'Instructor': Instructor})
        course.set_instructor(Instructor)

def update_credit_hours(course, CreditHours):
    with conn:
        c.execute("""UPDATE courses SET CreditHours = :CreditHours
                    WHERE CourseID = :CourseID""",
                    {'CourseID': course.get_courseID(), 'CreditHours': CreditHours})
        course.set_credit_hours(CreditHours)

def update_is_elective(course, isElective):
    with conn:
        c.execute("""UPDATE courses SET isElective = :isElective
                    WHERE CourseID = :CourseID""",
                    {'CourseID': course.get_courseID(), 'isElective': isElective})
        course.set_is_elective(isElective)

def update_weight(course, Weight):
    with conn:
        c.execute("""UPDATE courses SET Weight = :Weight
                    WHERE CourseID = :CourseID""",
                    {'CourseID': course.get_courseID(), 'Weight': Weight})
        course.set_weight(Weight)

def remove_course(course):
    with conn:
            c.execute("DELETE from courses WHERE CourseID = :CourseID",
            {'CourseID': course.get_courseID()})

#######################################################################################################################################################################

#demo courses
course1 = Course('CPSC3125', 'F,Su,Sp', 'CPSC2105', 'Dr. Who', 3, 'No', 87)

course2 = Course('CPSC4000', 'F,Su', 'CPSC3125', 'Dr. Joe', 3, 'No', 90)

insert_course(course1)

insert_course(course2)

#print(get_courses_by_id('CPSC3125'))

#print(get_all_courses())

update_instructor(course1, "Dr Lee")

print(get_all_courses())

update_course_id(course1, 'CPSC5000')

update_instructor(course1, 'Dr Lee')

print(get_all_courses())

remove_course(course2)

print(get_all_courses())

update_credit_hours(course1, 4)

#update_schedule(course1.get_courseID(), "Fall")

update_prereqId(course1, "Yes")

update_weight(course1, 1000)

update_is_elective(course1, "hell ya")

print(get_all_courses())

print(course1.get_courseID())

conn.commit()

conn.close()
