#insert into db hardcoded
#c.execute("INSERT INTO courses VALUES ('CPSC4000', 'F,Su', 'CPSC3125', 'Dr. Joe', 3, 'No', 90)")

#####################################################insert into db based on object values'####################################################################
#Method 1 - throwing error 'did not supply a value for binding 1'
# c.execute("INSERT INTO courses VALUES (:CourseId, :Schedule, :PrereqID, :Instructor, :CreditHours, :IsElective, :Weight)", 
# {'CourseID': course1.CourseId, 'Schedule': course1.Schedule, 'PrereqID': course1.PrereqId, 'Instructor': course1.Instructor, 
# 'CreditHours': course1.CreditHours, 'IsElective': course1.isElective, 'Weight': course1.Weight})

#redo of method 1 - works??
# c.execute("INSERT INTO courses VALUES (:CourseID, :Schedule, :PrereqID, :Instructor, :CreditHours, :isElective, :Weight)", 
# {'CourseID': course1.CourseId, 'Schedule': course1.Schedule, 'PrereqID': course1.PrereqId, 'Instructor': course1.Instructor, 
# 'CreditHours': course1.CreditHours, 'isElective': course1.isElective, 'Weight': course1.Weight})

#Method 2 
# c.execute("INSERT INTO courses VALUES (?, ?, ?, ?, ?, ?, ?)", 
# (course2.CourseId, course2.Schedule, course2.PrereqId, course2.Instructor, 
# course2.CreditHours, course2.isElective, course2.Weight))
################################################################################################################################################################
 
#retrieve all courses
#c.execute("SELECT * FROM courses")

#search db for course - hardcoded
#c.execute("SELECT * FROM courses WHERE Instructor='Dr. Who'")

#search db via method 1 - not hardcoded
#c.execute("SELECT * FROM courses WHERE CourseID=:CourseID", {'CourseID': 'CPSC4000'})

#search db via method 2 - not hardcoded - that weird comma at the end is needed as it is a tuple - otherwise will throw error
#c.execute("SELECT * FROM courses WHERE CourseID=?", ('CPSC4000',))

#return/print those values
#print(c.fetchall())
