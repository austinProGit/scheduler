from PySide6.QtWidgets import QApplication, QWidget, QPushButton, QMessageBox, QMainWindow
from PySide6.QtGui import QCloseEvent, QScreen

class Example(QWidget):
    def __init__(self):
        super().__init__()

        self.setup()

    def setup(self):
        self.setup_btns()
        self.set_screen_geo()
        self.center_screen()

        self.show()

    def set_screen_geo(self):
        self.setGeometry(0, 0, 600, 340)
        self.setWindowTitle('SQL Database Manager')
    
    def center_screen(self):
        center = QScreen.availableGeometry(QApplication.primaryScreen()).center()
        geo = self.frameGeometry()
        geo.moveCenter(center)
        self.move(geo.topLeft())

    def setup_btns(self):
        self.setup_btn_quit()
        self.setup_btn_view_all_courses()
        self.setup_btn_add_course()
        self.setup_btn_remove_course()
        self.setup_btn_search_courses()

    def setup_btn_quit(self):
        btn_quit = QPushButton('Force Quit', self)
        btn_quit.clicked.connect(QApplication.instance().quit)
        btn_quit.resize(btn_quit.sizeHint())
        btn_quit.move(500,290)

    def setup_btn_view_all_courses(self):
        btn_view_all_courses = QPushButton('View All Courses', self)
        #replace below with something like btn_view_all_courses.clicked.connect(sql_handler.print_courses) Need to import sql_handler obviously
        btn_view_all_courses.clicked.connect(QApplication.instance().quit)
        btn_view_all_courses.resize(btn_view_all_courses.sizeHint())
        btn_view_all_courses.move(90, 80)

    def setup_btn_add_course(self):
        btn_add_course = QPushButton('Add Course', self)
        #replace below with something like btn_view_all_courses.clicked.connect(sql_handler.add_course) Need to import sql_handler obviously
        btn_add_course.clicked.connect(QApplication.instance().quit)
        btn_add_course.resize(btn_add_course.sizeHint())
        btn_add_course.move(270, 80)

    def setup_btn_remove_course(self):
        btn_remove_course = QPushButton('Remove Course', self)
        #replace below with something like btn_view_all_courses.clicked.connect(sql_handler.remove_course) Need to import sql_handler obviously
        btn_remove_course.clicked.connect(QApplication.instance().quit)
        btn_remove_course.resize(btn_remove_course.sizeHint())
        btn_remove_course.move(450, 80)

    def setup_btn_search_courses(self):
        btn_search_courses = QPushButton('Search Courses', self)
        #replace below with something like btn_view_all_courses.clicked.connect(sql_handler.search_courses) Need to import sql_handler obviously
        btn_search_courses.clicked.connect(QApplication.instance().quit)
        btn_search_courses.resize(btn_search_courses.sizeHint())
        btn_search_courses.move(265, 180)
    
    def closeEvent(self, event: QCloseEvent):
        reply = QMessageBox.question(self, 'Message', 'Are you sure you want to quit?', QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if reply == QMessageBox.Yes:
            event.accept()
        
        else: 
            event.ignore()



def run():
    app = QApplication([])

    ex = Example()

    app.exec()


if __name__ == '__main__':
    run()