class Course:

    def __init__(self, CourseID, Schedule, PrereqId, Instructor, CreditHours, isElective, Weight):
        self.CourseId = CourseID
        self.Schedule = Schedule
        self.PrereqId = PrereqId
        self.Instructor = Instructor
        self.CreditHours = CreditHours
        self.isElective = isElective
        self.Weight = Weight


    def get_courseID(self):
        return self.CourseId

    def get_schedule(self):
        return self.Schedule
    
    def get_prereqId(self):
        return self.PrereqId

    def get_instructor(self):
        return self.Instructor

    def get_credit_hours(self):
        return self.CreditHours
    
    def get_is_elective(self):
        return self.isElective

    def get_weight(self):
        return self.Weight

    def set_courseID(self, new_course_Id):
        self.CourseId = new_course_Id

    def set_schedule(self, new_schedule):
        self.Schedule = new_schedule

    def set_prereqId(self, new_prereqId):
        self.PrereqId = new_prereqId

    def set_instructor(self, new_instructor):
        self.Instructor = new_instructor

    def set_credit_hours(self, new_credit_hours):
        self.CreditHours = new_credit_hours

    def set_is_elective(self, new_isElective):
        self.isElective = new_isElective

    def set_weight(self, new_weight):
        self.Weight = new_weight

    def __repr__(self):
        return "Course('{}', '{}', '{}', '{}', {}, '{}', {})".format(
            self.CourseId, self.Schedule, self.PrereqId, self.Instructor, 
            self.CreditHours, self.isElective, self.Weight)
